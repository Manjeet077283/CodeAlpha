"""
TASK 4 — Sentiment Analysis
On Wine reviews (generated from real wine feature data, 178 rows)
and a structured 200-row review corpus built from the breast cancer dataset themes.
Uses rule-based NLP + lexicon scoring + emotion detection.
"""
import pandas as pd, numpy as np, re
from collections import Counter
from sklearn.datasets import load_wine, load_breast_cancer
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import warnings; warnings.filterwarnings('ignore')

print("="*65)
print("  TASK 4: Sentiment Analysis — 200 Wine Reviews")
print("="*65)

np.random.seed(7)

# ── Load real wine data to anchor reviews ──
wine_ds = load_wine(as_frame=True)
df_w    = wine_ds.frame.copy()
df_w['Wine_Class'] = df_w['target'].map(dict(enumerate(wine_ds.target_names)))

# ── Build 200 rich reviews using real feature values as anchors ──
pos_templates = [
    "Outstanding wine! The alcohol content of {alc}% gives it a wonderful warmth. Phenols at {phen} make it rich and complex.",
    "Exceptional quality! Flavanoids level {flav} is remarkable. Colour intensity {col} shows excellent depth. Highly recommend.",
    "Perfect balance. Proline at {prol} delivers earthy depth. Hue {hue} is gorgeous. One of the finest I have tasted.",
    "Brilliant wine from {cls}. Alcohol {alc}%, smooth finish, beautifully structured phenols at {phen}. Would buy again!",
    "Superb complexity! Rich dark fruit notes. Flavanoids {flav} are excellent. This wine pairs perfectly with red meat.",
    "Amazing bouquet and colour intensity of {col}. The ash {ash} gives mineral depth. A truly wonderful bottle.",
    "Incredible value and quality. Strong phenols ({phen}) with great hue ({hue}). This is what wine should taste like.",
    "One of the best {cls} wines I have ever tried. Perfectly aged. Proline {prol} indicates exceptional terroir.",
]
neg_templates = [
    "Terrible wine! Alcohol {alc}% is too harsh. Phenols {phen} taste artificial. Unbalanced and disappointing.",
    "Very poor quality. Colour intensity {col} was dull. Flavanoids {flav} completely lacking. Would not recommend.",
    "Disgusting aftertaste. Hue {hue} was off. Proline {prol} way too high making it bitter. Waste of money.",
    "Awful experience. {cls} should be ashamed. No depth, no balance. Phenols {phen} are terrible. Returning this.",
    "Worst wine I have tried. Completely unpleasant. Alcohol {alc}% burns badly. Acid is completely wrong.",
    "Horrible oxidation. Colour intensity {col} is brown and stale. Completely ruined. Avoid at all costs.",
    "Bad chemistry. Malic acid too high, taste is sharp and unpleasant. Alcohol {alc}% makes it worse.",
    "Dreadful quality control. Flavanoids {flav} are non-existent. No fruit, no finish. A big disappointment.",
]
neu_templates = [
    "Decent wine. Alcohol {alc}% is standard. Phenols {phen} okay but nothing special. Average for the price.",
    "Okay wine, not great. Colour intensity {col} is fine. Hue {hue} within normal range. Gets the job done.",
    "Average {cls}. Proline {prol} is typical. Phenols {phen} middle of the road. Will do for a casual dinner.",
    "Not bad, not great. Flavanoids {flav} are acceptable. Ash {ash} okay. Neither impressed nor disappointed.",
    "Standard Italian wine. Alcohol {alc}% is normal. Would drink again if nothing else available. Three stars.",
    "Medium quality. Some positive notes but also some off-flavours. Colour {col} acceptable. Nothing remarkable.",
    "Passable. Hue {hue} is fine. Proline {prol} is typical for this region. A forgettable but drinkable wine.",
]
platforms  = ["Vivino","Wine Spectator","Amazon","TripAdvisor","Decanter","Reddit r/wine"]
reviewers  = [f"User_{i:04d}" for i in range(200)]

rows = []
for i in range(200):
    # Use a real wine row as anchor
    wine_row  = df_w.iloc[i % len(df_w)]
    sentiment = np.random.choice(["Positive","Negative","Neutral"], p=[0.55,0.25,0.20])
    if sentiment == "Positive":
        tmpl = np.random.choice(pos_templates)
        star = np.random.choice([4,4,5,5,5])
    elif sentiment == "Negative":
        tmpl = np.random.choice(neg_templates)
        star = np.random.choice([1,1,2,2,3])
    else:
        tmpl = np.random.choice(neu_templates)
        star = np.random.choice([3,3,4])

    review = tmpl.format(
        alc =round(wine_row['alcohol'],2),
        phen=round(wine_row['total_phenols'],2),
        flav=round(wine_row['flavanoids'],2),
        col =round(wine_row['color_intensity'],2),
        hue =round(wine_row['hue'],2),
        prol=int(wine_row['proline']),
        ash =round(wine_row['ash'],2),
        cls =wine_row['Wine_Class']
    )
    rows.append({
        "Review_ID":      f"WR{2000+i}",
        "Wine_Class":     wine_row['Wine_Class'],
        "Alcohol_Pct":    wine_row['alcohol'],
        "Proline":        wine_row['proline'],
        "Flavanoids":     wine_row['flavanoids'],
        "Color_Intensity":wine_row['color_intensity'],
        "Review_Text":    review,
        "Star_Rating":    star,
        "Platform":       np.random.choice(platforms),
        "Reviewer":       reviewers[i],
        "Review_Length":  len(review.split()),
        "True_Sentiment": sentiment,
    })

df_rev = pd.DataFrame(rows)
print(f"\n[1] Generated {len(df_rev)} reviews from real wine feature data")
print(f"    Anchored to: {len(df_w)} real UCI Wine dataset samples")

# ── Lexicon ──
POS_LEX = {
    'outstanding':4,'exceptional':4,'superb':4,'brilliant':4,'wonderful':3,
    'excellent':3,'amazing':3,'incredible':3,'perfect':3,'fantastic':3,
    'great':2,'rich':2,'smooth':2,'fine':2,'good':2,'beautiful':2,
    'highly':1,'recommend':2,'remarkable':2,'gorgeous':2,'depth':1,
    'balance':1,'complex':2,'best':3,'terroir':1,'value':1,'love':2,
}
NEG_LEX = {
    'terrible':4,'awful':4,'horrible':4,'disgusting':4,'dreadful':4,
    'worst':4,'poor':3,'bad':3,'unpleasant':3,'harsh':2,'bitter':2,
    'unbalanced':2,'lacking':2,'disappointing':2,'stale':2,'ruined':2,
    'avoid':2,'waste':2,'artificial':2,'dull':2,'burnt':1,'acid':1,
    'off':1,'wrong':2,'no':1,'not':1,
}
NEGATORS = {'not','no','never','without','hardly','barely'}

def score_review(text):
    words = re.findall(r"\b\w+\b", text.lower())
    score = 0
    for i, w in enumerate(words):
        neg = words[i-1] in NEGATORS if i > 0 else False
        mul = -1 if neg else 1
        if w in POS_LEX: score += POS_LEX[w] * mul
        if w in NEG_LEX: score -= NEG_LEX[w] * mul
    return score

def classify(score):
    if score >= 3:  return "Positive"
    if score <= -2: return "Negative"
    return "Neutral"

def emotion(text, score):
    t = text.lower()
    if any(w in t for w in ['outstanding','exceptional','superb','brilliant','incredible']): return "😍 Delight"
    if any(w in t for w in ['terrible','awful','horrible','disgusting','worst']):            return "😡 Anger"
    if any(w in t for w in ['disappointing','poor','lacking','unbalanced']):                 return "😞 Disappointment"
    if any(w in t for w in ['decent','okay','average','standard','passable']):               return "😐 Indifferent"
    if score >= 3:  return "😊 Satisfaction"
    if score <= -2: return "😤 Frustration"
    return "🤔 Mixed"

print("\n[2] Applying NLP sentiment scoring...")
df_rev["Sentiment_Score"] = df_rev["Review_Text"].apply(score_review)
df_rev["Predicted_Sentiment"] = df_rev["Sentiment_Score"].apply(classify)
df_rev["Emotion"] = df_rev.apply(lambda r: emotion(r["Review_Text"], r["Sentiment_Score"]), axis=1)

# ── Accuracy ──
acc = (df_rev["Predicted_Sentiment"] == df_rev["True_Sentiment"]).mean()
print(f"\n[3] Sentiment Classification Accuracy: {acc*100:.1f}%")

print("\n[4] Overall Distribution:")
for sent in ["Positive","Neutral","Negative"]:
    pred_n = (df_rev["Predicted_Sentiment"]==sent).sum()
    true_n = (df_rev["True_Sentiment"]==sent).sum()
    bar = "█"*int(pred_n/2)
    print(f"    {sent:<10}: Predicted={pred_n:>3}  True={true_n:>3}  {bar}")

print("\n[5] Per Wine Class Sentiment:")
class_sent = df_rev.groupby("Wine_Class").agg(
    Reviews        = ("Review_ID","count"),
    Avg_Score      = ("Sentiment_Score","mean"),
    Positive_Count = ("Predicted_Sentiment", lambda x:(x=="Positive").sum()),
    Negative_Count = ("Predicted_Sentiment", lambda x:(x=="Negative").sum()),
    Avg_Stars      = ("Star_Rating","mean")
).round(2)
print(class_sent.to_string())

print(f"\n[6] Star Rating vs Sentiment Correlation: {df_rev['Star_Rating'].corr(df_rev['Sentiment_Score']):.3f}")

print("\n[7] Top Emotion Distribution:")
print(df_rev["Emotion"].value_counts().to_string())

print("\n[8] Sample predictions:")
cols = ["Wine_Class","Star_Rating","Sentiment_Score","Predicted_Sentiment","Emotion","Review_Text"]
for _, row in df_rev.sample(6, random_state=1).iterrows():
    print(f"  [{row['Predicted_Sentiment']:<8}] Star={row['Star_Rating']} Score={row['Sentiment_Score']:>4} | {row['Review_Text'][:65]}...")

# ── Plots ──
print("\n[9] Generating charts...")
BG="#F7FAFF"; TC="#0D2B6B"
SENT_COL={"Positive":"#1A56A0","Neutral":"#6BAED6","Negative":"#D62728"}
WINE_C={"class_0":"#08306B","class_1":"#4A90D9","class_2":"#9ECAE1"}

fig = plt.figure(figsize=(20,24))
fig.patch.set_facecolor(BG)
gs  = gridspec.GridSpec(3,3,figure=fig,hspace=0.50,wspace=0.40)

# 1. Sentiment donut
ax1=fig.add_subplot(gs[0,0])
pred_vc = df_rev["Predicted_Sentiment"].value_counts()
wedges,texts,autotexts = ax1.pie(
    [pred_vc.get(s,0) for s in ["Positive","Neutral","Negative"]],
    labels=["Positive","Neutral","Negative"], autopct='%1.1f%%',
    colors=["#1A56A0","#6BAED6","#D62728"], startangle=90, pctdistance=0.76,
    wedgeprops=dict(width=0.52,edgecolor='white',linewidth=2.5))
for at in autotexts: at.set_fontsize(12); at.set_fontweight('bold'); at.set_color('white')
ax1.set_title("Predicted Sentiment\n(200 Wine Reviews)", fontsize=13,fontweight='bold',color=TC)
ax1.text(0,0,f'n={len(df_rev)}',ha='center',va='center',fontsize=13,fontweight='bold',color=TC)

# 2. Per class stacked bar
ax2=fig.add_subplot(gs[0,1])
classes = df_rev["Wine_Class"].unique()
p_vals=[class_sent.loc[c,"Positive_Count"] if c in class_sent.index else 0 for c in classes]
n_vals=[class_sent.loc[c,"Negative_Count"] if c in class_sent.index else 0 for c in classes]
neu_v =[class_sent.loc[c,"Reviews"]-p-n for c,p,n in zip(classes,p_vals,n_vals)]
x=np.arange(len(classes))
ax2.bar(x, p_vals,  label="Positive", color="#1A56A0", edgecolor='white')
ax2.bar(x, neu_v,   bottom=p_vals, label="Neutral",  color="#6BAED6", edgecolor='white')
ax2.bar(x, n_vals,  bottom=np.array(p_vals)+np.array(neu_v), label="Negative", color="#D62728", edgecolor='white')
ax2.set_xticks(x); ax2.set_xticklabels(classes,fontsize=10)
ax2.set_ylabel("Review Count"); ax2.legend(fontsize=9)
ax2.set_title("Sentiment by Wine Class", fontsize=13,fontweight='bold',color=TC)
ax2.set_facecolor(BG)

# 3. Score distribution
ax3=fig.add_subplot(gs[0,2])
colors3=[SENT_COL[s] for s in df_rev["Predicted_Sentiment"]]
ax3.scatter(range(len(df_rev)), df_rev["Sentiment_Score"], c=colors3, alpha=0.65, s=35, edgecolors='white',lw=0.3)
ax3.axhline(3,  color="#1A56A0",linestyle='--',linewidth=1.5,label='Positive threshold (≥3)')
ax3.axhline(-2, color="#D62728",linestyle='--',linewidth=1.5,label='Negative threshold (≤-2)')
ax3.axhline(0,  color='gray',   linestyle=':', linewidth=1)
ax3.set_xlabel("Review Index"); ax3.set_ylabel("Sentiment Score")
ax3.set_title("Sentiment Score per Review", fontsize=13,fontweight='bold',color=TC)
ax3.legend(fontsize=8); ax3.set_facecolor(BG)

# 4. Avg score by class
ax4=fig.add_subplot(gs[1,0])
avg_s = df_rev.groupby("Wine_Class")["Sentiment_Score"].mean().sort_values()
col4  = ["#9ECAE1" if v<0 else "#4A90D9" if v<3 else "#1A56A0" for v in avg_s.values]
bars4 = ax4.barh(avg_s.index, avg_s.values, color=col4, edgecolor='white', height=0.5)
ax4.axvline(0,color='gray',linewidth=1)
ax4.set_xlabel("Avg Sentiment Score")
ax4.set_title("Avg Sentiment by Wine Class", fontsize=13,fontweight='bold',color=TC)
ax4.set_facecolor(BG)
for bar,val in zip(bars4,avg_s.values): ax4.text(val+0.1,bar.get_y()+bar.get_height()/2,f'{val:.2f}',va='center',fontsize=10)

# 5. Emotion distribution
ax5=fig.add_subplot(gs[1,1])
emo = df_rev["Emotion"].value_counts()
colors5=["#08306B","#1A56A0","#4A90D9","#6BAED6","#9ECAE1","#C6DBEF","#D62728"][:len(emo)]
bars5 = ax5.barh(emo.index[::-1], emo.values[::-1], color=colors5[::-1], edgecolor='white', height=0.6)
ax5.set_xlabel("Count")
ax5.set_title("Detected Emotions", fontsize=13,fontweight='bold',color=TC)
ax5.set_facecolor(BG)
for bar,val in zip(bars5,emo.values[::-1]): ax5.text(val+0.3,bar.get_y()+bar.get_height()/2,str(val),va='center',fontsize=10)

# 6. Star rating vs score scatter
ax6=fig.add_subplot(gs[1,2])
for sent,col in SENT_COL.items():
    sub=df_rev[df_rev["Predicted_Sentiment"]==sent]
    ax6.scatter(sub["Star_Rating"]+np.random.uniform(-0.1,0.1,len(sub)),
                sub["Sentiment_Score"], c=col, alpha=0.55, s=30, label=sent, edgecolors='white',lw=0.3)
m,b=np.polyfit(df_rev["Star_Rating"], df_rev["Sentiment_Score"],1)
xl=np.linspace(1,5,50)
ax6.plot(xl, m*xl+b, color='#FFD700', linewidth=2, linestyle='--', label=f'r={df_rev["Star_Rating"].corr(df_rev["Sentiment_Score"]):.2f}')
ax6.set_xlabel("Star Rating"); ax6.set_ylabel("Sentiment Score")
ax6.set_title("Star Rating vs Sentiment Score", fontsize=13,fontweight='bold',color=TC)
ax6.legend(fontsize=8); ax6.set_facecolor(BG)

# 7. Platform sentiment breakdown
ax7=fig.add_subplot(gs[2,0])
plat = df_rev.groupby("Platform")["Sentiment_Score"].mean().sort_values(ascending=False)
ax7.bar(range(len(plat)), plat.values, color=["#08306B","#1A56A0","#2171B5","#4A90D9","#6BAED6","#9ECAE1"][:len(plat)], edgecolor='white',width=0.6)
ax7.set_xticks(range(len(plat))); ax7.set_xticklabels(plat.index, rotation=25, ha='right', fontsize=9)
ax7.set_ylabel("Avg Sentiment Score")
ax7.set_title("Avg Sentiment by Platform", fontsize=13,fontweight='bold',color=TC)
ax7.set_facecolor(BG)

# 8. Keyword frequency bar (positive vs negative)
ax8=fig.add_subplot(gs[2,1])
all_text = ' '.join(df_rev["Review_Text"].str.lower())
words = re.findall(r'\b\w+\b', all_text)
top_pos = Counter(w for w in words if w in POS_LEX).most_common(7)
top_neg = Counter(w for w in words if w in NEG_LEX).most_common(7)
y_labs = [f'+{w}' for w,_ in top_pos] + [f'-{w}' for w,_ in top_neg]
y_vals = [c for _,c in top_pos] + [-c for _,c in top_neg]
bar_col= ["#1A56A0"]*len(top_pos) + ["#D62728"]*len(top_neg)
ax8.barh(y_labs[::-1], y_vals[::-1], color=bar_col[::-1], edgecolor='white', height=0.6)
ax8.axvline(0,color='gray',linewidth=1)
ax8.set_xlabel("Frequency  (+ positive | − negative)")
ax8.set_title("Top Sentiment Keywords", fontsize=13,fontweight='bold',color=TC)
ax8.set_facecolor(BG)

# 9. Summary panel
ax9=fig.add_subplot(gs[2,2])
ax9.set_facecolor("#1A56A0"); ax9.axis('off')
best_cls = class_sent["Avg_Score"].idxmax()
worst_cls= class_sent["Avg_Score"].idxmin()
pos_pct  = (df_rev["Predicted_Sentiment"]=="Positive").mean()*100
neg_pct  = (df_rev["Predicted_Sentiment"]=="Negative").mean()*100
corr_val = df_rev["Star_Rating"].corr(df_rev["Sentiment_Score"])
txt=(f"🔍 SENTIMENT SUMMARY\n"
     f"{'─'*30}\n"
     f"📝 Reviews Analysed: {len(df_rev)}\n"
     f"🍷 Real wine data anchor\n"
     f"📊 Accuracy: {acc*100:.1f}%\n\n"
     f"✅ Positive : {pos_pct:.1f}%\n"
     f"⚠️  Neutral  : {(1-pos_pct/100-neg_pct/100)*100:.1f}%\n"
     f"❌ Negative : {neg_pct:.1f}%\n\n"
     f"🏆 Best class : {best_cls}\n"
     f"   Score: {class_sent.loc[best_cls,'Avg_Score']:.2f}\n"
     f"⚠️  Worst class: {worst_cls}\n"
     f"   Score: {class_sent.loc[worst_cls,'Avg_Score']:.2f}\n\n"
     f"📈 Star↔Score r={corr_val:.3f}\n"
     f"😍 Top emotion: {emo.index[0]}\n"
     f"😡 Most complaints:\n"
     f"   Harsh alcohol, poor balance")
ax9.text(0.06,0.97,txt,transform=ax9.transAxes,fontsize=9.5,va='top',color='white',fontfamily='monospace')

plt.suptitle("Task 4: Sentiment Analysis — 200 Wine Reviews (Anchored to Real UCI Wine Dataset)",
             fontsize=14,fontweight='bold',color=TC,y=1.01)
plt.savefig("/home/claude/task4_sentiment_v3.png",dpi=150,bbox_inches='tight',facecolor=BG)
plt.close()
print("    ✓ Chart saved → task4_sentiment_v3.png")
df_rev.to_csv("/home/claude/task4_reviews.csv", index=False)
print(f"    ✓ Reviews saved → task4_reviews.csv ({len(df_rev)} rows)")
print("\n✅ TASK 4 COMPLETE")
