"""
TASK 2 — Exploratory Data Analysis
On Breast Cancer dataset: 569 rows × 31 features
"""
import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from scipy import stats
from sklearn.datasets import load_breast_cancer
import warnings; warnings.filterwarnings('ignore')

print("="*65)
print("  TASK 2: EDA — Breast Cancer Dataset (569 rows × 31 cols)")
print("="*65)

ds = load_breast_cancer(as_frame=True)
df = ds.frame.copy()
df['diagnosis'] = df['target'].map({1:'Benign', 0:'Malignant'})
df['target_name'] = df['diagnosis']

BG="#F7FAFF"; TC="#0D2B6B"
BPAL=["#1A56A0","#4A90D9","#9ECAE1","#C6DBEF","#08306B","#2171B5","#6BAED6","#DEEBF7"]
SENT_COL={"Benign":"#1A56A0","Malignant":"#D62728"}

# ── 1. Overview ──
print(f"\n[1] Shape          : {df.shape}")
print(f"    Columns        : {list(df.columns[:8])}...")
print(f"    Data types     : {df.dtypes.value_counts().to_dict()}")

print("\n[2] Class Balance:")
vc = df['diagnosis'].value_counts()
for cls, cnt in vc.items():
    print(f"    {cls:<12}: {cnt:>4} ({cnt/len(df)*100:.1f}%)")

print("\n[3] Missing Values:")
mv = df.isnull().sum()
print(f"    Total missing  : {mv.sum()} {'✓ None' if mv.sum()==0 else ''}")

print("\n[4] Descriptive Statistics (first 10 features):")
feat_cols = [c for c in df.columns if c not in ['target','diagnosis','target_name']][:10]
print(df[feat_cols].describe().round(3).to_string())

# ── 2. Outlier Detection ──
print("\n[5] Outlier Detection (IQR method):")
outlier_report = []
for col in feat_cols:
    q1,q3 = df[col].quantile(0.25), df[col].quantile(0.75)
    iqr   = q3 - q1
    n_out = ((df[col]<q1-1.5*iqr)|(df[col]>q3+1.5*iqr)).sum()
    outlier_report.append({'Feature':col,'Q1':round(q1,3),'Q3':round(q3,3),'IQR':round(iqr,3),'Outliers':n_out})
print(pd.DataFrame(outlier_report).to_string(index=False))

# ── 3. Feature Analysis by Diagnosis ──
print("\n[6] Feature Means by Diagnosis:")
key_feats = ['mean radius','mean texture','mean perimeter','mean area',
             'mean smoothness','mean compactness','mean concavity','mean symmetry']
group_means = df.groupby('diagnosis')[key_feats].mean().round(3)
print(group_means.to_string())

# ── 4. Correlation Analysis ──
print("\n[7] Top 10 Features Correlated with Target:")
num_df = df[feat_cols + ['target']]
corr_target = num_df.corr()['target'].drop('target').abs().sort_values(ascending=False)
print(corr_target.head(10).round(4).to_string())

# ── 5. Hypothesis Testing ──
print("\n[8] Statistical Tests:")
for feat in ['mean radius','mean area','mean texture']:
    benign    = df[df['diagnosis']=='Benign'][feat]
    malignant = df[df['diagnosis']=='Malignant'][feat]
    t, p = stats.ttest_ind(benign, malignant)
    print(f"    T-Test [{feat}]: t={t:.3f}, p={p:.2e} → {'Significant ✓' if p<0.05 else 'Not significant'}")

stat, p_ks = stats.ks_2samp(
    df[df['diagnosis']=='Benign']['mean radius'],
    df[df['diagnosis']=='Malignant']['mean radius'])
print(f"    KS-Test [mean radius]: stat={stat:.3f}, p={p_ks:.2e} → {'Different distributions ✓' if p_ks<0.05 else 'Similar'}")

# ── 6. Distribution insights ──
print("\n[9] Key Insights:")
print(f"    Avg mean radius  — Benign: {df[df.diagnosis=='Benign']['mean radius'].mean():.2f}  |  Malignant: {df[df.diagnosis=='Malignant']['mean radius'].mean():.2f}")
print(f"    Avg mean area    — Benign: {df[df.diagnosis=='Benign']['mean area'].mean():.1f}  |  Malignant: {df[df.diagnosis=='Malignant']['mean area'].mean():.1f}")
print(f"    Avg mean texture — Benign: {df[df.diagnosis=='Benign']['mean texture'].mean():.2f}  |  Malignant: {df[df.diagnosis=='Malignant']['mean texture'].mean():.2f}")

# ── 7. Generate Charts ──
print("\n[10] Generating EDA charts...")
plt.style.use("seaborn-v0_8-whitegrid")
fig = plt.figure(figsize=(22, 28))
fig.patch.set_facecolor(BG)
gs  = gridspec.GridSpec(4,3,figure=fig,hspace=0.46,wspace=0.38)

# 1. Class distribution
ax1=fig.add_subplot(gs[0,0])
vals = df['diagnosis'].value_counts()
wedges,texts,autotexts = ax1.pie(vals.values, labels=vals.index,
    autopct='%1.1f%%', colors=["#1A56A0","#D62728"],
    startangle=90, pctdistance=0.75,
    wedgeprops=dict(width=0.5,edgecolor='white',linewidth=2))
for at in autotexts: at.set_fontsize(12); at.set_fontweight('bold'); at.set_color('white')
ax1.set_title("Diagnosis Distribution\n(569 patients)",fontsize=13,fontweight='bold',color=TC)

# 2. Mean radius by diagnosis (violin)
ax2=fig.add_subplot(gs[0,1])
benign_r   = df[df['diagnosis']=='Benign']['mean radius'].values
malignant_r= df[df['diagnosis']=='Malignant']['mean radius'].values
parts = ax2.violinplot([benign_r, malignant_r], showmedians=True)
for pc,col in zip(parts['bodies'],["#1A56A0","#D62728"]): pc.set_facecolor(col); pc.set_alpha(0.8)
ax2.set_xticks([1,2]); ax2.set_xticklabels(['Benign','Malignant'])
ax2.set_ylabel("Mean Radius"); ax2.set_title("Mean Radius by Diagnosis",fontsize=13,fontweight='bold',color=TC)
ax2.set_facecolor(BG)

# 3. Feature correlation bar with target
ax3=fig.add_subplot(gs[0,2])
top10 = corr_target.head(10)
colors3=["#1A56A0" if v>0.7 else "#4A90D9" if v>0.5 else "#9ECAE1" for v in top10.values]
bars3=ax3.barh(top10.index[::-1], top10.values[::-1], color=colors3[::-1], edgecolor='white',height=0.6)
ax3.set_xlabel("Correlation with Target (abs)")
ax3.set_title("Top 10 Features\nCorrelated with Diagnosis",fontsize=13,fontweight='bold',color=TC)
ax3.axvline(0.7,color='#FFD700',linewidth=1.5,linestyle='--',label='r=0.7')
ax3.legend(fontsize=9); ax3.set_facecolor(BG)
for bar,val in zip(bars3,top10.values[::-1]): ax3.text(val+0.005,bar.get_y()+bar.get_height()/2,f'{val:.3f}',va='center',fontsize=8)

# 4. Heatmap of mean features
ax4=fig.add_subplot(gs[1,0])
mean_feats = [c for c in df.columns if 'mean' in c and c not in ['target','diagnosis','target_name']][:10]
corr_m = df[mean_feats].corr()
mask   = np.triu(np.ones_like(corr_m,dtype=bool))
sns.heatmap(corr_m,ax=ax4,mask=mask,annot=True,fmt=".2f",cmap="Blues",
            linewidths=0.5,annot_kws={"size":7},cbar_kws={"shrink":0.8})
ax4.set_title("Feature Correlation Heatmap\n(Mean Features)",fontsize=13,fontweight='bold',color=TC)
ax4.tick_params(axis='x',rotation=40,labelsize=7); ax4.tick_params(axis='y',labelsize=7)

# 5. Boxplot of 4 key features
ax5=fig.add_subplot(gs[1,1])
key4 = ['mean radius','mean texture','mean smoothness','mean symmetry']
df_norm = df[key4+['diagnosis']].copy()
for k in key4: df_norm[k] = (df_norm[k]-df_norm[k].mean())/df_norm[k].std()
data_b = [df_norm[df_norm['diagnosis']=='Benign'][k].values for k in key4]
data_m = [df_norm[df_norm['diagnosis']=='Malignant'][k].values for k in key4]
pos_b = np.array([1,3,5,7]); pos_m = pos_b+0.8
bp_b = ax5.boxplot(data_b, positions=pos_b, widths=0.7, patch_artist=True, notch=True)
bp_m = ax5.boxplot(data_m, positions=pos_m, widths=0.7, patch_artist=True, notch=True)
for p in bp_b['boxes']: p.set_facecolor("#1A56A0"); p.set_alpha(0.75)
for p in bp_m['boxes']: p.set_facecolor("#D62728"); p.set_alpha(0.75)
ax5.set_xticks(pos_b+0.4)
ax5.set_xticklabels(['Radius','Texture','Smoothness','Symmetry'],fontsize=9)
ax5.set_ylabel("Normalised Value")
ax5.set_title("Key Features by Diagnosis\n(Normalised)",fontsize=13,fontweight='bold',color=TC)
from matplotlib.patches import Patch
ax5.legend(handles=[Patch(color="#1A56A0",label='Benign'),Patch(color="#D62728",label='Malignant')],fontsize=9)
ax5.set_facecolor(BG)

# 6. Scatter: radius vs area coloured by diagnosis
ax6=fig.add_subplot(gs[1,2])
for diag, col in SENT_COL.items():
    sub = df[df['diagnosis']==diag]
    ax6.scatter(sub['mean radius'], sub['mean area'], c=col, alpha=0.55, s=30, label=diag, edgecolors='white',lw=0.3)
ax6.set_xlabel("Mean Radius"); ax6.set_ylabel("Mean Area")
ax6.set_title("Mean Radius vs Mean Area",fontsize=13,fontweight='bold',color=TC)
ax6.legend(fontsize=10); ax6.set_facecolor(BG)

# 7. Histogram: mean texture
ax7=fig.add_subplot(gs[2,0])
for diag, col in SENT_COL.items():
    sub = df[df['diagnosis']==diag]['mean texture']
    ax7.hist(sub, bins=25, alpha=0.65, color=col, label=diag, edgecolor='white')
ax7.set_xlabel("Mean Texture"); ax7.set_ylabel("Count")
ax7.set_title("Mean Texture Distribution",fontsize=13,fontweight='bold',color=TC)
ax7.legend(); ax7.set_facecolor(BG)

# 8. Histogram: mean concavity
ax8=fig.add_subplot(gs[2,1])
for diag, col in SENT_COL.items():
    sub = df[df['diagnosis']==diag]['mean concavity']
    ax8.hist(sub, bins=25, alpha=0.65, color=col, label=diag, edgecolor='white')
ax8.set_xlabel("Mean Concavity"); ax8.set_ylabel("Count")
ax8.set_title("Mean Concavity Distribution",fontsize=13,fontweight='bold',color=TC)
ax8.legend(); ax8.set_facecolor(BG)

# 9. Pairplot substitute (scatter matrix of 4 features)
ax9=fig.add_subplot(gs[2,2])
ax9.scatter(df['mean perimeter'], df['mean concave points'],
            c=df['target'].map({1:"#1A56A0",0:"#D62728"}), alpha=0.5, s=25, edgecolors='white',lw=0.3)
ax9.set_xlabel("Mean Perimeter"); ax9.set_ylabel("Mean Concave Points")
ax9.set_title("Perimeter vs Concave Points",fontsize=13,fontweight='bold',color=TC)
from matplotlib.patches import Patch
ax9.legend(handles=[Patch(color="#1A56A0",label='Benign'),Patch(color="#D62728",label='Malignant')],fontsize=9)
ax9.set_facecolor(BG)

# 10. Outlier count per feature
ax10=fig.add_subplot(gs[3,0])
out_counts = pd.DataFrame(outlier_report).set_index('Feature')['Outliers'].sort_values(ascending=False)
colors10=["#D62728" if v>30 else "#4A90D9" for v in out_counts.values]
ax10.barh(out_counts.index[::-1], out_counts.values[::-1], color=colors10[::-1], edgecolor='white', height=0.6)
ax10.set_xlabel("Number of Outliers")
ax10.set_title("Outliers per Feature (IQR)",fontsize=13,fontweight='bold',color=TC)
ax10.axvline(30,color='#FFD700',linestyle='--',linewidth=1.5,label='30 threshold')
ax10.legend(fontsize=9); ax10.set_facecolor(BG)

# 11. Feature means comparison (radar-style bar)
ax11=fig.add_subplot(gs[3,1])
feats_compare = ['mean radius','mean texture','mean smoothness','mean compactness','mean symmetry']
b_means = df[df['diagnosis']=='Benign'][feats_compare].mean()
m_means = df[df['diagnosis']=='Malignant'][feats_compare].mean()
b_norm  = b_means / m_means
m_norm  = m_means / m_means
x = np.arange(len(feats_compare)); w=0.35
ax11.bar(x-w/2, b_norm.values, w, label='Benign',    color="#1A56A0", edgecolor='white')
ax11.bar(x+w/2, m_norm.values, w, label='Malignant', color="#D62728", edgecolor='white')
ax11.set_xticks(x); ax11.set_xticklabels([f.replace('mean ','') for f in feats_compare],rotation=20,fontsize=9)
ax11.axhline(1.0,color='gray',linestyle='--',linewidth=1)
ax11.set_ylabel("Ratio vs Malignant Mean")
ax11.set_title("Feature Ratio: Benign vs Malignant",fontsize=13,fontweight='bold',color=TC)
ax11.legend(fontsize=10); ax11.set_facecolor(BG)

# 12. Findings panel
ax12=fig.add_subplot(gs[3,2])
ax12.set_facecolor("#1A56A0"); ax12.axis('off')
txt=(f"📊 EDA FINDINGS\n"
     f"{'─'*30}\n"
     f"📁 Dataset: Breast Cancer\n"
     f"   {df.shape[0]} rows × {df.shape[1]} cols\n\n"
     f"🟦 Benign:    {vc['Benign']} ({vc['Benign']/len(df)*100:.1f}%)\n"
     f"🔴 Malignant: {vc['Malignant']} ({vc['Malignant']/len(df)*100:.1f}%)\n\n"
     f"🔗 Top corr feature:\n"
     f"   {corr_target.index[0]}\n"
     f"   r = {corr_target.iloc[0]:.4f}\n\n"
     f"📈 T-Test (mean radius):\n"
     f"   p << 0.001 ✓ Significant\n\n"
     f"⚠️  Most outliers:\n"
     f"   {out_counts.index[0]} ({out_counts.iloc[0]})\n\n"
     f"✅ No missing values")
ax12.text(0.06,0.97,txt,transform=ax12.transAxes,fontsize=10,va='top',color='white',fontfamily='monospace')

plt.suptitle("Task 2: EDA — Breast Cancer Dataset  (569 rows × 31 features)",
             fontsize=15,fontweight='bold',color=TC,y=1.01)
plt.savefig("/home/claude/task2_eda_v3.png",dpi=150,bbox_inches='tight',facecolor=BG)
plt.close()
print("    ✓ Chart saved → task2_eda_v3.png")
print("\n✅ TASK 2 COMPLETE")
