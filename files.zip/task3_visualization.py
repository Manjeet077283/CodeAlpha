"""
TASK 3 — Data Visualization
On Wine (178 rows) + Breast Cancer (569 rows) + Diabetes (442 rows)
"""
import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.datasets import load_wine, load_breast_cancer, load_diabetes
import warnings; warnings.filterwarnings('ignore')

print("="*65)
print("  TASK 3: Data Visualization — 3 Real Datasets")
print("="*65)

wine_ds = load_wine(as_frame=True)
df_w    = wine_ds.frame.copy()
df_w['Wine_Class'] = df_w['target'].map(dict(enumerate(wine_ds.target_names)))

bc_ds   = load_breast_cancer(as_frame=True)
df_bc   = bc_ds.frame.copy()
df_bc['diagnosis'] = df_bc['target'].map({1:'Benign', 0:'Malignant'})

diab_ds = load_diabetes(as_frame=True)
df_d    = diab_ds.frame.copy()

BG="#F7FAFF"; TC="#0D2B6B"
BPAL=["#08306B","#1A56A0","#2171B5","#4A90D9","#6BAED6","#9ECAE1","#C6DBEF","#DEEBF7"]
DIAG_COL={"Benign":"#1A56A0","Malignant":"#D62728"}
WINE_COL={"class_0":"#08306B","class_1":"#4A90D9","class_2":"#9ECAE1"}

plt.style.use("seaborn-v0_8-whitegrid")
fig = plt.figure(figsize=(22,30))
fig.patch.set_facecolor(BG)
gs  = gridspec.GridSpec(4,3,figure=fig,hspace=0.50,wspace=0.38)

# ── CHART 1: Wine alcohol by class (violin) ──
ax1=fig.add_subplot(gs[0,0])
classes = wine_ds.target_names
data_v  = [df_w[df_w['Wine_Class']==c]['alcohol'].values for c in classes]
parts   = ax1.violinplot(data_v, showmedians=True, showmeans=True)
for pc,col in zip(parts['bodies'],["#08306B","#4A90D9","#9ECAE1"]):
    pc.set_facecolor(col); pc.set_alpha(0.82)
parts['cmedians'].set_color('#FFD700'); parts['cmeans'].set_color('white')
ax1.set_xticks([1,2,3]); ax1.set_xticklabels(classes, fontsize=10)
ax1.set_ylabel("Alcohol %"); ax1.set_facecolor(BG)
ax1.set_title("🍷 Wine Alcohol by Class\n(178 Italian wines)", fontsize=12, fontweight='bold', color=TC)
for i,(cls,d) in enumerate(zip(classes,data_v)):
    ax1.text(i+1, max(d)+0.05, f'μ={np.mean(d):.2f}', ha='center', fontsize=8, color=TC, fontweight='bold')

# ── CHART 2: Wine feature radar (group averages) ──
ax2=fig.add_subplot(gs[0,1], polar=True)
feats_r = ['alcohol','malic_acid','total_phenols','flavanoids','color_intensity','hue']
angles  = np.linspace(0,2*np.pi,len(feats_r),endpoint=False).tolist()
angles += angles[:1]
for cls,col in WINE_COL.items():
    vals = df_w[df_w['Wine_Class']==cls][feats_r].mean().tolist()
    vals_n = [(v-df_w[f].min())/(df_w[f].max()-df_w[f].min()) for v,f in zip(vals,feats_r)]
    vals_n += vals_n[:1]
    ax2.plot(angles, vals_n, 'o-', color=col, linewidth=2, label=cls)
    ax2.fill(angles, vals_n, alpha=0.12, color=col)
ax2.set_xticks(angles[:-1]); ax2.set_xticklabels(feats_r, fontsize=8)
ax2.set_ylim(0,1); ax2.set_facecolor(BG)
ax2.set_title("🕸 Wine Feature Radar\n(Normalised per class)", fontsize=12, fontweight='bold', color=TC, pad=22)
ax2.legend(loc='upper right', bbox_to_anchor=(1.25,1.15), fontsize=9)

# ── CHART 3: BC diagnosis donut ──
ax3=fig.add_subplot(gs[0,2])
vc = df_bc['diagnosis'].value_counts()
wedges,texts,autotexts = ax3.pie(vc.values, labels=vc.index, autopct='%1.1f%%',
    colors=["#1A56A0","#D62728"], startangle=90, pctdistance=0.78,
    wedgeprops=dict(width=0.52, edgecolor='white', linewidth=3))
for at in autotexts: at.set_fontsize(12); at.set_fontweight('bold'); at.set_color('white')
ax3.set_title("🔬 Breast Cancer Diagnosis\n(569 patients)", fontsize=12, fontweight='bold', color=TC)
ax3.text(0,0,f'n={len(df_bc)}', ha='center', va='center', fontsize=14, fontweight='bold', color=TC)

# ── CHART 4: Diabetes BMI vs target (disease progression) ──
ax4=fig.add_subplot(gs[1,0])
sc = ax4.scatter(df_d['bmi'], df_d['target'], c=df_d['bp'], cmap='Blues',
                 alpha=0.6, s=30, edgecolors='white', lw=0.3)
plt.colorbar(sc, ax=ax4, label='Blood Pressure', shrink=0.8)
m,b = np.polyfit(df_d['bmi'], df_d['target'], 1)
x_l = np.linspace(df_d['bmi'].min(), df_d['bmi'].max(), 100)
ax4.plot(x_l, m*x_l+b, color='#D62728', linewidth=2, linestyle='--', label=f'r={df_d["bmi"].corr(df_d["target"]):.2f}')
ax4.set_xlabel("BMI (standardised)"); ax4.set_ylabel("Disease Progression")
ax4.set_title("💊 BMI vs Diabetes Progression\n(442 patients)", fontsize=12, fontweight='bold', color=TC)
ax4.legend(fontsize=10); ax4.set_facecolor(BG)

# ── CHART 5: BC top 5 features grouped bar ──
ax5=fig.add_subplot(gs[1,1])
top5 = ['mean radius','mean perimeter','mean area','mean concavity','mean concave points']
b_m  = df_bc[df_bc['diagnosis']=='Benign'][top5].mean()
m_m  = df_bc[df_bc['diagnosis']=='Malignant'][top5].mean()
b_n  = b_m / (b_m + m_m)
m_n  = m_m / (b_m + m_m)
x    = np.arange(len(top5)); w=0.35
ax5.bar(x-w/2, b_n.values, w, label='Benign',    color="#1A56A0", edgecolor='white')
ax5.bar(x+w/2, m_n.values, w, label='Malignant', color="#D62728", edgecolor='white')
ax5.set_xticks(x); ax5.set_xticklabels([f.replace('mean ','') for f in top5], rotation=15, fontsize=9)
ax5.set_ylabel("Proportion of Sum"); ax5.legend(fontsize=10)
ax5.set_title("🔬 Feature Split: Benign vs Malignant", fontsize=12, fontweight='bold', color=TC)
ax5.set_facecolor(BG)

# ── CHART 6: Wine proline vs flavanoids coloured by class ──
ax6=fig.add_subplot(gs[1,2])
for cls,col in WINE_COL.items():
    sub = df_w[df_w['Wine_Class']==cls]
    ax6.scatter(sub['proline'], sub['flavanoids'], c=col, alpha=0.7, s=45,
                label=cls, edgecolors='white', lw=0.5)
ax6.set_xlabel("Proline"); ax6.set_ylabel("Flavanoids")
ax6.set_title("🍷 Proline vs Flavanoids\nby Wine Class", fontsize=12, fontweight='bold', color=TC)
ax6.legend(fontsize=10); ax6.set_facecolor(BG)

# ── CHART 7: Wine correlation heatmap ──
ax7=fig.add_subplot(gs[2,0])
wine_feats = [c for c in df_w.columns if c not in ['target','Wine_Class']]
corr_w = df_w[wine_feats].corr()
mask   = np.triu(np.ones_like(corr_w, dtype=bool))
sns.heatmap(corr_w, ax=ax7, mask=mask, annot=True, fmt=".1f", cmap="Blues",
            linewidths=0.4, annot_kws={"size":6}, cbar_kws={"shrink":0.75})
ax7.set_title("🍷 Wine Feature Correlations", fontsize=12, fontweight='bold', color=TC)
ax7.tick_params(axis='x', rotation=40, labelsize=7); ax7.tick_params(axis='y', labelsize=7)

# ── CHART 8: Diabetes feature distributions ──
ax8=fig.add_subplot(gs[2,1])
diab_feats = ['age','bmi','bp','s1']
colors8    = ["#08306B","#1A56A0","#4A90D9","#9ECAE1"]
for feat, col in zip(diab_feats, colors8):
    norm = (df_d[feat]-df_d[feat].mean())/df_d[feat].std()
    ax8.hist(norm, bins=20, alpha=0.55, label=feat.upper(), color=col, edgecolor='white')
ax8.set_xlabel("Standardised Value"); ax8.set_ylabel("Count")
ax8.set_title("💊 Diabetes Feature Distributions\n(Standardised)", fontsize=12, fontweight='bold', color=TC)
ax8.legend(fontsize=9); ax8.set_facecolor(BG)

# ── CHART 9: BC — mean concave points by diagnosis (CDF) ──
ax9=fig.add_subplot(gs[2,2])
for diag, col in DIAG_COL.items():
    data_sorted = np.sort(df_bc[df_bc['diagnosis']==diag]['mean concave points'].values)
    cdf = np.arange(1, len(data_sorted)+1) / len(data_sorted)
    ax9.plot(data_sorted, cdf, color=col, linewidth=2.5, label=diag)
ax9.set_xlabel("Mean Concave Points"); ax9.set_ylabel("CDF")
ax9.set_title("🔬 CDF: Mean Concave Points\nBenign vs Malignant", fontsize=12, fontweight='bold', color=TC)
ax9.legend(fontsize=10); ax9.axhline(0.5, color='gray', linestyle='--', linewidth=1)
ax9.set_facecolor(BG)

# ── CHART 10: Wine magnesium boxplot ──
ax10=fig.add_subplot(gs[3,0])
bp_data = [df_w[df_w['Wine_Class']==c]['magnesium'].values for c in classes]
bp10 = ax10.boxplot(bp_data, labels=classes, patch_artist=True, notch=True,
                    medianprops=dict(color='#FFD700', linewidth=2))
for patch, col in zip(bp10['boxes'],["#08306B","#4A90D9","#9ECAE1"]):
    patch.set_facecolor(col); patch.set_alpha(0.8)
ax10.set_ylabel("Magnesium (mg/L)")
ax10.set_title("🍷 Magnesium by Wine Class", fontsize=12, fontweight='bold', color=TC)
ax10.set_facecolor(BG)

# ── CHART 11: Diabetes s1 vs target (Serum cholesterol) ──
ax11=fig.add_subplot(gs[3,1])
df_d_q = df_d.copy()
df_d_q['s1_group'] = pd.qcut(df_d['s1'], q=4, labels=['Q1','Q2','Q3','Q4'])
grp_means = df_d_q.groupby('s1_group')['target'].mean()
colors11 = ["#9ECAE1","#4A90D9","#2171B5","#08306B"]
bars11=ax11.bar(grp_means.index, grp_means.values, color=colors11, edgecolor='white', width=0.6)
ax11.set_xlabel("Serum Cholesterol Quartile (s1)")
ax11.set_ylabel("Avg Disease Progression")
ax11.set_title("💊 Cholesterol Quartile\nvs Disease Progression", fontsize=12, fontweight='bold', color=TC)
ax11.set_facecolor(BG)
for bar,val in zip(bars11,grp_means.values): ax11.text(bar.get_x()+bar.get_width()/2, val+1, f'{val:.1f}', ha='center', fontsize=10, fontweight='bold', color=TC)

# ── CHART 12: Dataset summary panel ──
ax12=fig.add_subplot(gs[3,2])
ax12.set_facecolor("#08306B"); ax12.axis('off')
txt=(f"📊 VISUALIZATION SUMMARY\n"
     f"{'─'*32}\n\n"
     f"🍷 WINE (UCI Dataset)\n"
     f"   {len(df_w)} samples, {len(wine_feats)} features\n"
     f"   3 cultivar classes from Italy\n"
     f"   Charts: 1,2,6,7,10\n\n"
     f"🔬 BREAST CANCER (UCI)\n"
     f"   {len(df_bc)} samples, 30 features\n"
     f"   Benign 62.7% | Malignant 37.3%\n"
     f"   Charts: 3,5,9\n\n"
     f"💊 DIABETES (Sklearn)\n"
     f"   {len(df_d)} samples, 10 features\n"
     f"   BMI-Progression r=0.59\n"
     f"   Charts: 4,8,11\n\n"
     f"Total records: {len(df_w)+len(df_bc)+len(df_d):,}\n"
     f"Total charts : 12\n"
     f"Libraries    : Matplotlib, Seaborn")
ax12.text(0.06,0.97,txt,transform=ax12.transAxes,fontsize=10,va='top',color='white',fontfamily='monospace')

plt.suptitle("Task 3: Data Visualization — Wine (178) + Breast Cancer (569) + Diabetes (442)",
             fontsize=14,fontweight='bold',color=TC,y=1.01)
plt.savefig("/home/claude/task3_viz_v3.png",dpi=150,bbox_inches='tight',facecolor=BG)
plt.close()
print("    ✓ Chart saved → task3_viz_v3.png")
print("\n✅ TASK 3 COMPLETE")
